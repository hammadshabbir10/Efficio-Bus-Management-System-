package UI_Controller;

import java.io.IOException;

import JAVAFX.BMS_Controller;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class PassengerFeedbackController {

    @FXML
    private TextArea feedbackTextArea;

    @FXML
    private Button backButton;

    @FXML
    private Button star1, star2, star3, star4, star5;

    private int rating = 0;


    @FXML
    private void setRating1() {
        rating = 1;
        updateStarStyles();
    }

    @FXML
    private void setRating2() {
        rating = 2;
        updateStarStyles();
    }

    @FXML
    private void setRating3() {
        rating = 3;
        updateStarStyles();
    }

    @FXML
    private void setRating4() {
        rating = 4;
        updateStarStyles();
    }

    @FXML
    private void setRating5() {
        rating = 5;
        updateStarStyles();
    }
    private void updateStarStyles() {
     
        star1.setStyle("-fx-font-size: 20px; -fx-background-color: transparent; -fx-text-fill: #FFD700;");
        star2.setStyle("-fx-font-size: 20px; -fx-background-color: transparent; -fx-text-fill: #FFD700;");
        star3.setStyle("-fx-font-size: 20px; -fx-background-color: transparent; -fx-text-fill: #FFD700;");
        star4.setStyle("-fx-font-size: 20px; -fx-background-color: transparent; -fx-text-fill: #FFD700;");
        star5.setStyle("-fx-font-size: 20px; -fx-background-color: transparent; -fx-text-fill: #FFD700;");

        if (rating >= 1) star1.setStyle("-fx-font-size: 20px; -fx-background-color: transparent; -fx-text-fill: #e74c3c;");
        if (rating >= 2) star2.setStyle("-fx-font-size: 20px; -fx-background-color: transparent; -fx-text-fill: #e74c3c;");
        if (rating >= 3) star3.setStyle("-fx-font-size: 20px; -fx-background-color: transparent; -fx-text-fill: #e74c3c;");
        if (rating >= 4) star4.setStyle("-fx-font-size: 20px; -fx-background-color: transparent; -fx-text-fill: #e74c3c;");
        if (rating >= 5) star5.setStyle("-fx-font-size: 20px; -fx-background-color: transparent; -fx-text-fill: #e74c3c;");
    }

    @FXML
    private void submitFeedback() {
        String feedback = feedbackTextArea.getText();

        if (rating == 0 || feedback.isEmpty()) {
            showAlert("Fill all"," Please provide both a rating and feedback.");
            return;
        }

        BMS_Controller bmsController = new BMS_Controller();
        bmsController.submitFeedback(rating, feedback);
    }
    

    @FXML
    private void goBack() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/PassengerScreen.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            Scene scene = new Scene(root, 500, 600);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

}