package UI_Controller;

import java.io.IOException;

import JAVAFX.LoggedInManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class StationManagerLoginScreenController {
    @FXML
    private TextField nameTextField;
    @FXML
    private TextField passwordTextField;
    @FXML
    private Button backButton;

    @FXML
    private void handleLogin() {
        String username = nameTextField.getText();
        String password = passwordTextField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showAlert("Missing Field", "Username and password fields cannot be empty.",Alert.AlertType.ERROR);
            return;
        }

        LoggedInManager loggedInManager = new LoggedInManager();
        loggedInManager.login(username, password);

        String managerName = LoggedInManager.getName();
        if (managerName != null) 
        {   
            System.out.println("Login successful. Manager Name: " + managerName);
            showAlert("Success", "Login Successful.",Alert.AlertType.INFORMATION);
            navigateToScreen("/FXML_FILES/StationManagerScreen.fxml");
        } 
        else 
        {
            
            showAlert("Login Error", "Invalid username or password. Please try again.",Alert.AlertType.ERROR);
        }
    }


    @FXML
    private void handleCreateAccount() {
        navigateToScreen("/FXML_FILES/StationManagerCreateAccountScreen.fxml");
    }

    private void navigateToScreen(String fxmlFile) {
        try 
        {
            Parent root = FXMLLoader.load(getClass().getResource(fxmlFile));
            Stage stage = (Stage) nameTextField.getScene().getWindow();
            Scene scene = new Scene(root, 800, 600); 
            stage.setScene(scene);
            stage.show();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
           
        }
    }
    
    @FXML
    private void handleBackButton() {
        try {
           
            Parent adminScreen = FXMLLoader.load(getClass().getResource("/FXML_FILES/main.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            Scene scene = new Scene(adminScreen, 600, 400);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

}