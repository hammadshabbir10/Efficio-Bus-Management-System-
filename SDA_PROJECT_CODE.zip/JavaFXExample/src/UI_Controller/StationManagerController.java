package UI_Controller;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.IOException;

public class StationManagerController 
{

	@FXML
	private Button createAccountButton;
	@FXML
	private Button addBusButton;
	@FXML
	private Button assignStationToBusButton;
	@FXML
	private Button backButton;
	@FXML
	private Button manageRefundButton;
	@FXML
	private Button reviewComplaint;
	@FXML
	private Button deleteBusButton;
	    
	
	 @FXML
	    public void initialize() {
	        // Apply fade-in animation to all buttons
	        fadeInButton(createAccountButton);
	        fadeInButton(addBusButton);
	        fadeInButton(assignStationToBusButton);
	        fadeInButton(manageRefundButton);
	        fadeInButton(reviewComplaint);
	        fadeInButton(deleteBusButton);
	        fadeInButton(backButton);
	    }

	    private void fadeInButton(Node node) {
	        FadeTransition fadeIn = new FadeTransition(Duration.seconds(1), node);
	        fadeIn.setFromValue(0.0); 
	        fadeIn.setToValue(1.0);   
	        fadeIn.setCycleCount(1);
	        fadeIn.setAutoReverse(false);
	        fadeIn.play();
	    }
	    
	    
	@FXML
    private void openCreateAccountScreen() 
	{
        try 
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/StationManagerCreateAccountScreen.fxml"));
            Parent root = loader.load();
        	Stage stage = (Stage) createAccountButton.getScene().getWindow();
            Scene scene = new Scene(root, 600, 400);
            stage.setScene(scene);
            stage.show();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
	 @FXML
	 public void openAddBusScreen() 
	 {
	        try {
	          
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/Bus.fxml"));
	            Parent root = loader.load();

	            
	            Stage stage = (Stage) addBusButton.getScene().getWindow();
	            stage.setTitle("Add Bus");
	            stage.setScene(new Scene(root));
	            stage.show();
	        } catch (IOException e) {
	            e.printStackTrace();
	            System.out.println("Failed to load Bus.fxml: " + e.getMessage());
	        }
	    }
	 
	  @FXML
	    private void openAssignStationToBusScreen() {
	        try {
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/AssignStationToBus.fxml"));
	            Parent root = loader.load();
	            Stage stage = (Stage) assignStationToBusButton.getScene().getWindow();
	            stage.setTitle("Assign Station to Bus");
	            stage.setScene(new Scene(root));
	            stage.show();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	  

	    @FXML
	    private void goBackToMainScreen() {
	        try {
	        
	            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/main.fxml"));    
	            Stage stage = (Stage) backButton.getScene().getWindow();
	            Scene scene = new Scene(root, 600, 400);  
	            stage.setScene(scene);
	            stage.show();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    @FXML
	    private void openManageRefundScreen() {
	        try {
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/approveCancellation.fxml"));
	            Parent root = loader.load();
	            Stage stage = (Stage) manageRefundButton.getScene().getWindow();
	            stage.setTitle("Refunds");
	            stage.setScene(new Scene(root));
	            stage.show();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	   
	    @FXML
	    private void openReviewComplaintScreen() {
	        try {
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/StationManagerReviewComplaint.fxml"));
	            Parent root = loader.load();
	            Stage stage = (Stage) reviewComplaint.getScene().getWindow();
	            stage.setTitle("Review Comlpaint");
	            stage.setScene(new Scene(root));
	            stage.show();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	  
	    @FXML
	    private void openDeleteBusScreen() {
	        try {
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/StationManagerDeleteBus.fxml"));
	            Parent root = loader.load();
	            Stage stage = (Stage) deleteBusButton.getScene().getWindow();
	            stage.setTitle("Review Comlpaint");
	            stage.setScene(new Scene(root));
	            stage.show();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	 
}
