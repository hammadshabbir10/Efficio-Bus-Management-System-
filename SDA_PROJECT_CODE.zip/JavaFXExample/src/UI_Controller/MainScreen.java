package UI_Controller;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class MainScreen {
    private Stage stage;

    public MainScreen(Stage stage) {
        this.stage = stage;
    }

    public Scene createMainScene() {
        Parent root;
        try {
            
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/main.fxml"));
            root = loader.load();
            MainScreenController controller = loader.getController();
            controller.setStage(stage); 
            Scene mainScene = new Scene(root, 500, 600);
            return mainScene;
        } catch (IOException e) {
            e.printStackTrace();
            return null; 
        }
    }
}
