package UI_Controller;

import java.io.IOException;

import JAVAFX.BMS_Controller;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AdminCreateAccountController {
    @FXML
    private TextField nameTextField;
    @FXML
    private TextField emailTextField;
    @FXML
    private TextField passwordTextField;
    @FXML
    private TextField phoneNumberTextField;

    @FXML
    private void createAccount() {
        String name = nameTextField.getText();
        String email = emailTextField.getText();
        String password = passwordTextField.getText();
        String phoneNumber = phoneNumberTextField.getText();

        // Validation checks
        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || phoneNumber.isEmpty()) {
            showAlert("Error", "Fields cannot be empty.");
            return;
        }

        if (!isValidEmail(email)) {
            showAlert("Error", "Invalid email format.");
            return;
        }

        if (!isStrongPassword(password)) {
            showAlert("Weak Password", "Password must be at least 8 characters long, " +
                    "contain one uppercase letter, one number, and one special character.");
            return;
        }

        if (!isValidPhoneNumber(phoneNumber)) {
            showAlert("Error", "Invalid phone number. It should be 10-15 digits.");
            return;
        }

        // Create account logic
        BMS_Controller controller = new BMS_Controller();
        int generatedId = controller.handleCreateAccountAdmin(name, email, password, phoneNumber);

        if (generatedId != -1) {
            showAlert("Account Created", "Account successfully created with ID: " + generatedId);
        } else {
            showAlert("Error", "Failed to create account. Please try again.");
        }
    }

    @FXML
    private void goBack() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/AdminLoginScreen.fxml"));
            Stage stage = (Stage) nameTextField.getScene().getWindow();
            Scene scene = new Scene(root, 500, 600);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        return email.matches(emailRegex);
    }

    private boolean isStrongPassword(String password) {
        String passwordRegex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[\\$&@]).{8,}$";
        return password.matches(passwordRegex);
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        String phoneRegex = "^[0-9]{10,15}$";
        return phoneNumber.matches(phoneRegex);
    }
}
