package UI_Controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import DBLayer.DataBaseConnection;
import JAVAFX.BMS_Controller;

public class AdminAddRouteController {

    @FXML
    private TextField routeIdField;
    @FXML
    private TextField routeNameField;
    @FXML
    private TextField startStationField;
    @FXML
    private TextField endStationField;
    @FXML
    private TextField distanceField;
    @FXML
    private TextField startTimeField;
    @FXML
    private TextField endTimeField;
    @FXML
    private ComboBox<String> busNumberComboBox;
    @FXML
    private Button addRouteButton;
    @FXML
    private Button backButton;
    @FXML
    private ComboBox<String> startStationComboBox;
    @FXML
    private ComboBox<String> endStationComboBox;
    @FXML
    private DatePicker operationalDatePicker;

    
    @FXML
    private void initialize() {
    	 populateStations(); 
        populateBusNumbers();
    }


    private void populateBusNumbers() {
        try {
            Connection connection = DataBaseConnection.getConnection();
            String query = "SELECT busNumber FROM Bus";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            ArrayList<String> busNumbers = new ArrayList<>();
            while (resultSet.next()) {
                busNumbers.add(resultSet.getString("busNumber"));
            }
            busNumberComboBox.getItems().addAll(busNumbers);

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load bus numbers from the database.");
        }
    }
    
    private void populateStations() {
        try {
            Connection connection = DataBaseConnection.getConnection();
            String query = "SELECT name FROM Station"; 
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            ArrayList<String> stations = new ArrayList<>();
            while (resultSet.next()) {
                stations.add(resultSet.getString("name"));
            }

            startStationComboBox.getItems().addAll(stations);
            endStationComboBox.getItems().addAll(stations);

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load station names from the database.");
        }
    }

    private boolean isBusAssignedToStations(String busNumber, String startStation, String endStation) {
        try {
            Connection connection = DataBaseConnection.getConnection();
            String query = "SELECT COUNT(*) FROM StationBusAssignments WHERE busNumber = ? AND stationName IN (?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, busNumber);
            statement.setString(2, startStation);
            statement.setString(3, endStation);
            
            System.out.println("Checking bus assignment: busNumber=" + busNumber + ", startStation=" + startStation + ", endStation=" + endStation);
            
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
               
                System.out.println("Result from database: " + resultSet.getInt(1));
                return resultSet.getInt(1) == 2; // Ensure both stations are assigned
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @FXML
    private void handleAddRoute() {
    	String routeName = routeNameField.getText();
        String startStation = startStationComboBox.getValue();
        String endStation = endStationComboBox.getValue();
        String distance = distanceField.getText();
        String startTime = startTimeField.getText();
        String endTime = endTimeField.getText();
        String busNumber = busNumberComboBox.getValue();

        LocalDate operationalDate = operationalDatePicker.getValue();

        
        // Validate that both start and end stations are selected
        if (routeName.isEmpty() || startStation == null || endStation == null || distance.isEmpty() 
            || startTime.isEmpty() || endTime.isEmpty() || busNumber == null || operationalDate == null) {
            showAlert("Error", "All fields must be filled and a bus number must be selected.");
            return;
        }

        if (!isBusAssignedToStations(busNumber, startStation, endStation)) {
            showAlert("Error", "The selected bus is not assigned to the selected stations.");
            return;
        }

        try {
            
            BMS_Controller bms = new BMS_Controller();
            boolean isAdded = bms.manageRoute(routeName,startStation, endStation, distance, startTime, endTime, busNumber,operationalDate);

            if (isAdded) 
            {
               
                boolean statusUpdated = updateBusStatus(busNumber, "Rented");
                if (statusUpdated) {
                    showAlert("Success", "Route added successfully. Bus status updated to 'Rented'.");
                } 
                else 
                {
                    showAlert("Warning", "Route added, but failed to update bus status.");
                }
                clearFields();
            } 
            else 
            {
                showAlert("Error", "Failed to add the route.");
            }
        } 
        catch (NumberFormatException e) {
            showAlert("Error", "Invalid number format in Route ID or Distance field.");
        }
    }
    
    public boolean updateBusStatus(String busNumber, String status) {
        String query = "UPDATE Bus SET status = ? WHERE busNumber = ?";
        try (Connection conn = DataBaseConnection.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, status);
            stmt.setString(2, busNumber);
            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            System.err.println("Error updating bus status: " + e.getMessage());
            return false;
        }
    }
    
    @FXML
    private void handleBack() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/AdminScreen.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            Scene scene = new Scene(root, 500, 600);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void clearFields() {
     
        routeNameField.clear();
        startStationField.clear();
        endStationField.clear();
        distanceField.clear();
        startTimeField.clear();
        endTimeField.clear();
        busNumberComboBox.getSelectionModel().clearSelection();
    }
}