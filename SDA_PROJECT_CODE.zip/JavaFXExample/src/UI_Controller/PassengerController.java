package UI_Controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.io.IOException;
import javafx.animation.FadeTransition;
import javafx.scene.Node;
import javafx.util.Duration;


public class PassengerController {

	@FXML
	private Button createAccountButton;
	@FXML
	private Button checkScheduleButton;
	@FXML
	private Button backButton;
	@FXML
	private Button bookTicketButton; 
	@FXML
	private Button viewBookingsButton;
	@FXML
	private Button giveFeedbackButton;
	@FXML
	private Button  lodgeComplaintButton;
	    
	
	 @FXML
	    public void initialize() {
	        // Apply fade-in animation to all buttons
	        fadeInButton(createAccountButton);
	        fadeInButton(checkScheduleButton);
	        fadeInButton(viewBookingsButton);
	        fadeInButton(bookTicketButton);
	        fadeInButton(giveFeedbackButton);
	        fadeInButton(lodgeComplaintButton);
	        fadeInButton(backButton);
	    }

	    private void fadeInButton(Node node) {
	        FadeTransition fadeIn = new FadeTransition(Duration.seconds(1), node);
	        fadeIn.setFromValue(0.0); 
	        fadeIn.setToValue(1.0);   
	        fadeIn.setCycleCount(1);
	        fadeIn.setAutoReverse(false);
	        fadeIn.play();
	    }
	    
	    
	@FXML
    private void openCreateAccountScreen() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/PassengerCreateAcccountScreen.fxml"));
            Parent root = loader.load();
        	Stage stage = (Stage) createAccountButton.getScene().getWindow();
            Scene scene = new Scene(root, 600, 400);
            stage.setTitle("Create an Account");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	
    @FXML
    private void handleCheckScheduleButtonClick() {
        try {
                  
           
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/PassengerCheckSchedule.fxml"));
            Parent root = loader.load();
        	Stage stage = (Stage) checkScheduleButton.getScene().getWindow();
            Scene scene = new Scene(root, 600, 400);
            stage.setTitle("Check Schedule");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    private void handleBookTicketButtonClick() { 
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/PassengerBookTicket.fxml")); 
            Parent root = loader.load();
            Stage stage = (Stage) bookTicketButton.getScene().getWindow();
            Scene scene = new Scene(root, 600, 400);
            stage.setTitle("Book Ticket");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @FXML
    private void handleViewBookingsButtonClick() { 
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/viewBookings.fxml")); 
            Parent root = loader.load();
            Stage stage = (Stage) bookTicketButton.getScene().getWindow();
            Scene scene = new Scene(root, 600, 400);
            stage.setTitle("View Bookings");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void openFeedbackScreen() {
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/PassengerFeedback.fxml")); 
            Parent root = loader.load();
            Stage stage = (Stage) giveFeedbackButton.getScene().getWindow();
            Scene scene = new Scene(root, 600, 400);
            stage.setTitle("Give Feedback");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @FXML
    private void openComplaintScreen() {
       
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/PassengerComplaint.fxml"));
            Parent complaintScreen = loader.load();
            Scene complaintScene = new Scene(complaintScreen);
            Stage stage = (Stage) lodgeComplaintButton.getScene().getWindow();
            stage.setTitle("Give Complaint");
            stage.setScene(complaintScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @FXML
    private void goBackToMainScreen() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/main.fxml"));
            
            Stage stage = (Stage) backButton.getScene().getWindow();
            Scene scene = new Scene(root, 600, 400);  
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}