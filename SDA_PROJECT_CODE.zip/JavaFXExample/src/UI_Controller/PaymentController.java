package UI_Controller;

import JAVAFX.Payment;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class PaymentController {

    @FXML
    private RadioButton cardRadioButton;

    @FXML
    private RadioButton easypaisaRadioButton;

    @FXML
    private TextField cardNumberField;

    @FXML
    private TextField cvvField;

    @FXML
    private TextField easypaisaAccountField;

    @FXML
    private TextField otpField;

    @FXML
    private Label statusLabel;

    private ToggleGroup paymentMethodGroup = new ToggleGroup();
    private boolean paymentSuccessful = false;

    @FXML
    private void initialize() {
       
        cardRadioButton.setToggleGroup(paymentMethodGroup);
        easypaisaRadioButton.setToggleGroup(paymentMethodGroup);

        paymentMethodGroup.selectedToggleProperty().addListener((observable, oldValue, newValue) -> {
            if (cardRadioButton.isSelected()) {
                cardNumberField.setDisable(false);
                cvvField.setDisable(false);
                easypaisaAccountField.setDisable(true);
                otpField.setDisable(true);
            } else if (easypaisaRadioButton.isSelected()) {
                cardNumberField.setDisable(true);
                cvvField.setDisable(true);
                easypaisaAccountField.setDisable(false);
                otpField.setDisable(false);
            }
        });

        cardRadioButton.setSelected(true);
        cardNumberField.setDisable(false);
        cvvField.setDisable(false);
        easypaisaAccountField.setDisable(true);
        otpField.setDisable(true);
    }

    public boolean isPaymentSuccessful() {
        return paymentSuccessful;
    }

    @FXML
    private void handleConfirmPayment() {
        String method = cardRadioButton.isSelected() ? "Card" : "Easypaisa";
        String accountOrCardNumber;
        String transactionCode;

        if ("Card".equals(method)) {
            accountOrCardNumber = cardNumberField.getText();
            transactionCode = cvvField.getText();
        } else {
            accountOrCardNumber = easypaisaAccountField.getText();
            transactionCode = otpField.getText();
        }

        if (accountOrCardNumber.isEmpty() || transactionCode.isEmpty()) {
            statusLabel.setText("All fields are required.");
            return;
        }

        Payment payment = new Payment(method, accountOrCardNumber, transactionCode);
        if (payment.savePayment()) {
            statusLabel.setText("Payment successful.");
            paymentSuccessful = true;

            statusLabel.getScene().getWindow().hide();
        } else {
            statusLabel.setText("Payment failed. Try again.");
        }
    }

    @FXML
    private void goBackToBookingScreen() {
        
        statusLabel.getScene().getWindow().hide();
    }
}
