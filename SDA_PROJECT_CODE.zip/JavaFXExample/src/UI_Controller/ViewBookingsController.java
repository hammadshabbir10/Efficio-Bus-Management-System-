package UI_Controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import DBLayer.DataBaseConnection;
import JAVAFX.LoggedInPassenger;

public class ViewBookingsController {

    @FXML
    private TableView<Booking> bookingsTable;

    @FXML
    private TableColumn<Booking, Integer> ticketIdColumn;

    @FXML
    private TableColumn<Booking, String> routeNameColumn;

    @FXML
    private TableColumn<Booking, String> bookingDateColumn;

    @FXML
    private TableColumn<Booking, String> bookingStatusColumn;

    @FXML
    private Button viewDetailsButton;

    @FXML
    private Button backButton;

    @FXML
    private Label statusLabel;
    

    @FXML
    private void initialize() 
    {
        ticketIdColumn.setCellValueFactory(new PropertyValueFactory<>("ticketId"));
        routeNameColumn.setCellValueFactory(new PropertyValueFactory<>("routeName"));
        bookingDateColumn.setCellValueFactory(new PropertyValueFactory<>("bookingDate"));

        loadBookings();
    }
    
    private void loadBookings() {
        ObservableList<Booking> bookings = FXCollections.observableArrayList();

        int passengerId = LoggedInPassenger.getPassengerId();

        String query = "SELECT t.ticketId, r.routeName, t.bookingDate " +
                       "FROM Tickets t " +
                       "JOIN Routes r ON t.routeId = r.routeId " +
                       "WHERE t.passengerId = ?";

        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {

            stmt.setInt(1, passengerId); 

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                bookings.add(new Booking(
                    rs.getInt("ticketId"),
                    rs.getString("routeName"),
                    rs.getDate("bookingDate")
                ));
            }

            bookingsTable.setItems(bookings); 

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "There was an issue loading your bookings.");
        }
    }


    @FXML
    private void handleViewDetails() 
    {
      
        Booking selectedBooking = bookingsTable.getSelectionModel().getSelectedItem();
        if (selectedBooking != null) 
        {
           
            statusLabel.setText("Booking ID: " + selectedBooking.getTicketId() + "\n" +
                                "Route: " + selectedBooking.getRouteName() + "\n" +
                                "Booking Date: " + selectedBooking.getBookingDate());
        } 
        else 
        {
            statusLabel.setText("Please select a booking to view details.");
        }
    }

    @FXML
    private void openCancelTicketDialog()
    {
    	try {
            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/CancelTicket.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            Scene scene = new Scene(root, 600, 400);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e)  {
            e.printStackTrace();
        }
    }
    @FXML
    private void goBackToBookingScreen() {
    	try {
            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/PassengerScreen.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            Scene scene = new Scene(root, 600, 400);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e)            {
            e.printStackTrace();
        }
    }

    // Booking class to hold the booking data
    public static class Booking {
        private final SimpleIntegerProperty ticketId;
        private final SimpleStringProperty routeName;
        private final SimpleObjectProperty<java.sql.Date> bookingDate;

        public Booking(int ticketId, String routeName, java.sql.Date bookingDate) {
            this.ticketId = new SimpleIntegerProperty(ticketId);
            this.routeName = new SimpleStringProperty(routeName);
            this.bookingDate = new SimpleObjectProperty<>(bookingDate);
        }

        public int getTicketId() {
            return ticketId.get();
        }

        public String getRouteName() {
            return routeName.get();
        }

        public String getBookingDate() {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            return sdf.format(bookingDate.get());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
