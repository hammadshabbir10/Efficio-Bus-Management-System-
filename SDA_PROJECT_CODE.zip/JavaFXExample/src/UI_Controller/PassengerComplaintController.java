package UI_Controller;

import javafx.scene.control.Button;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import DBLayer.DataBaseConnection;
import JAVAFX.BMS_Controller;

public class PassengerComplaintController {


    @FXML
    private TextArea complaintTextArea;
    
    @FXML
    private Button backButton;
    @FXML
    private ComboBox<String> complaintTypeComboBox;
    @FXML
    private ComboBox<String> stationManagerComboBox;

    @FXML
    public void initialize() {
       
        ObservableList<String> complaintTypes = FXCollections.observableArrayList(
            "Service-related", "Bus-related", "Timeliness", "Other"
        );
        
        complaintTypeComboBox.setItems(complaintTypes);
        loadManagers();
        
    }
    
    private void loadManagers() 
    {
        try (Connection connection = DataBaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT name FROM StationManager")) {

            while (resultSet.next()) 
            {
                stationManagerComboBox.getItems().add(resultSet.getString("name"));
            }

        } catch (Exception e) {
            e.printStackTrace();
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Database Error");
            alert.setHeaderText(null);
            alert.setContentText("Unable to load station managers. Please try again later.");
            alert.showAndWait();
        }
    }
    

    
    @FXML
    private void submitComplaint() {
        String complaintType = complaintTypeComboBox.getValue();
        String complaintDescription = complaintTextArea.getText();
        String selectedManager = stationManagerComboBox.getValue();

        if (complaintType == null || complaintDescription.isEmpty() || selectedManager == null)
        {
            System.out.println("Please provide all required fields: Complaint Type, Description, and Station Manager.");
            return;
        }

        BMS_Controller bmsController = new BMS_Controller();
        bmsController.submitComplaint(complaintType, complaintDescription, selectedManager);

        complaintTypeComboBox.getSelectionModel().clearSelection();
        complaintTextArea.clear();
        stationManagerComboBox.getSelectionModel().clearSelection();
      
    }

    
    @FXML
    private void goBack() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/PassengerScreen.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            Scene scene = new Scene(root, 500, 600);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}