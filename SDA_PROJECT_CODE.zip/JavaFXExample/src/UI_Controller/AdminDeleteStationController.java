package UI_Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import javafx.scene.control.Button;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import DBLayer.DataBaseConnection;
import JAVAFX.BMS_Controller;


public class AdminDeleteStationController {

    @FXML
    private ComboBox<String> stationComboBox;

    @FXML
    private Button deleteButton;

    @FXML
    private Button backButton;

    public List<String> getAvailableStation() {
        List<String> availableRoutes = new ArrayList<>();
        try (Connection conn = DataBaseConnection.getConnection()) {
            String query = "SELECT name FROM Station"; 
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                availableRoutes.add(rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return availableRoutes;
    }

    @FXML
    public void initialize() {
       
        ObservableList<String> availableRoutes = FXCollections.observableArrayList(getAvailableStation());
        stationComboBox.setItems(availableRoutes);
    }

    @FXML
    public void deleteSelectedStation() {
        String selectedStation = stationComboBox.getValue();
        if (selectedStation == null) {
            showAlert("Error", "No station selected!", Alert.AlertType.ERROR);
            return;
        }

        BMS_Controller bmsController =  new BMS_Controller();
        boolean isDeleted = bmsController.deleteStation(selectedStation);

        if (isDeleted) {
            showAlert("Success", "Station deleted successfully!", Alert.AlertType.INFORMATION);
            stationComboBox.getItems().remove(selectedStation);
        } else {
            showAlert("Error", "Station could not be deleted!", Alert.AlertType.ERROR);
        }
    }
    
    @FXML
    private void goBackAdminScreen() {
        try {
          
            Parent adminScreen = FXMLLoader.load(getClass().getResource("/FXML_FILES/AdminScreen.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            Scene scene = new Scene(adminScreen, 600, 400);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}