package UI_Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import DBLayer.DataBaseConnection;
import JAVAFX.Complaint;
import JAVAFX.LoggedInManager;

public class StationManagerReviewComplaintController {

    @FXML
    private TableView<Complaint> complaintsTable;

    @FXML
    private TableColumn<Complaint, Integer> passengerIdColumn;

    @FXML
    private TableColumn<Complaint, String> complaintTypeColumn;

    @FXML
    private TableColumn<Complaint, String> complaintDescriptionColumn;

    @FXML
    private Button backButton;

    @FXML
    public void initialize() {
       
        passengerIdColumn.setCellValueFactory(new PropertyValueFactory<>("passengerId"));
        complaintTypeColumn.setCellValueFactory(new PropertyValueFactory<>("complaintType"));
        complaintDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("complaintDescription"));
        loadComplaints();
    }

    private void loadComplaints() {
        ObservableList<Complaint> complaintsList = FXCollections.observableArrayList();

        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "SELECT c.passengerId, c.complaintType, c.complaintDescription " +
                             "FROM Complaints c JOIN Passengers p ON c.passengerId = p.passengerId " +
                             "WHERE c.stationManager = ?")) {

            preparedStatement.setString(1, LoggedInManager.getName());
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                complaintsList.add(new Complaint(
                        resultSet.getInt("passengerId"),
                        resultSet.getString("complaintType"),
                        resultSet.getString("complaintDescription")
                ));
            }

            complaintsTable.setItems(complaintsList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void goBackToManagerScreen() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/StationManagerScreen.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            Scene scene = new Scene(root, 500, 600);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
