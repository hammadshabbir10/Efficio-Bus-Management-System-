package UI_Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import javafx.scene.control.Button;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import DBLayer.DataBaseConnection;
import JAVAFX.BMS_Controller;



public class StationManagerDeleteBusController {

    @FXML
    private ComboBox<String> busComboBox;

    @FXML
    private Button deleteButton;

    @FXML
    private Button backButton;


    
     public List<String> getAvailableBuses() {
        List<String> availableBuses = new ArrayList<>();
        try (Connection conn = DataBaseConnection.getConnection()) {
            String query = "SELECT busNumber FROM Bus WHERE status = 'Available'";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                availableBuses.add(rs.getString("busNumber"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return availableBuses;
    }

    @FXML
    public void initialize() {
      
        ObservableList<String> availableBuses = FXCollections.observableArrayList(getAvailableBuses());
        busComboBox.setItems(availableBuses);
    }

    @FXML
    public void deleteSelectedBus() {
        String selectedBus = busComboBox.getValue();
        if (selectedBus == null) {
            showAlert("Error", "No bus selected!", Alert.AlertType.ERROR);
            return;
        }

        BMS_Controller bmsController =  new BMS_Controller();
        boolean isDeleted = bmsController.deleteBus(selectedBus);

        if (isDeleted) {
            showAlert("Success", "Bus deleted successfully!", Alert.AlertType.INFORMATION);
            busComboBox.getItems().remove(selectedBus);
        } else {
            showAlert("Error", "Bus cannot be deleted as it is rented or assigned!", Alert.AlertType.ERROR);
        }
    }
    
    @FXML
    private void goBackSMScreen() {
        try {
            // Load the AdminScreen FXML
            Parent adminScreen = FXMLLoader.load(getClass().getResource("/FXML_FILES/StationManagerScreen.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            Scene scene = new Scene(adminScreen, 600, 400);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
