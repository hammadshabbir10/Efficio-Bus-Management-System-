package JAVAFX;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class AdminScreen {
    private Stage stage;

    public AdminScreen(Stage stage) {
        this.stage = stage;
    }

    public Scene createAdminScene() {
        try 
        {
            // Load PassengerScreen.fxml
            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/AdminScreen.fxml"));
            return new Scene(root, 600, 400);
        } 
        catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}

