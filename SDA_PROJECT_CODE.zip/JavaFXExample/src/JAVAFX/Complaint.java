package JAVAFX;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javafx.scene.control.Alert;
import DBLayer.DataBaseConnection;

public class Complaint {

	   private int complaintId;
	   private int passengerId;
	   private String complaintType;
	   private String complaintDescription;
	   private String stationManager;
	    
	   public Complaint() {};
	   
	   public Complaint(int passengerId, String complaintType, String complaintDescription, String stationManager) {
	        this.passengerId = passengerId;
	        this.complaintType = complaintType;
	        this.complaintDescription = complaintDescription;
	        this.stationManager = stationManager;
	    }
	   
	   public Complaint(int complaintId,int passengerId, String complaintType, String complaintDescription, String stationManager) {
	        this.complaintId = complaintId;
		    this.passengerId = passengerId;
	        this.complaintType = complaintType;
	        this.complaintDescription = complaintDescription;
	        this.stationManager = stationManager;
	    }

	    // Constructor
	    public Complaint(Integer passengerId, String complaintType, String description) {
	        this.passengerId = passengerId;
	        this.complaintType = complaintType;
	        this.complaintDescription = description;
	    }

	    
	    public int getComplaintId() {
	        return complaintId;
	    }

	   
	    public String getComplaintDescription() {
	        return complaintDescription;
	    }

	    public String getStationManager() {
	        return stationManager;
	    }
	    
	    public Integer getPassengerId() {
	        return passengerId;
	    }


	    public String getComplaintType() {
	        return complaintType;
	    }

	    public void saveComplaintToDatabase(int passengerId, String complaintType, String complaintDescription, String stationManager) {
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                 "INSERT INTO Complaints (passengerId, complaintType, complaintDescription, stationManager) VALUES (?, ?, ?, ?)"
             )) {
            
            preparedStatement.setInt(1, passengerId);
            preparedStatement.setString(2, complaintType);
            preparedStatement.setString(3, complaintDescription);
            preparedStatement.setString(4, stationManager);

            preparedStatement.executeUpdate();
            System.out.println("Complaint successfully lodged in the database.");
            
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Complaint Submission");
            alert.setHeaderText(null);
            alert.setContentText("Your complaint has been successfully submitted.");
            alert.showAndWait();

        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Database Error");
            alert.setHeaderText(null);
            alert.setContentText("An error occurred while lodging your complaint. Please try again.");
            alert.showAndWait();
        }
    }
}
