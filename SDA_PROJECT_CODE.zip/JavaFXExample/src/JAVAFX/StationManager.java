package JAVAFX;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.scene.control.Alert;
import DBLayer.DataBaseConnection;

public class StationManager extends User{


    public StationManager() {   super(); }
    public StationManager(String name, String email, String password, String phonenumber) {
    	super(name, email,  password,phonenumber);
    }

    @Override
    public int createAccount() {
        String checkEmailQuery = "SELECT COUNT(*) FROM StationManager WHERE email = ?";
        String checkNameQuery = "SELECT COUNT(*) FROM StationManager WHERE name = ?";
        String insertQuery = "INSERT INTO StationManager (name, email, password, phonenumber) VALUES (?, ?, ?, ?)";
        int generatedId = -1;

        try (Connection connection = DataBaseConnection.getConnection()) {
            
            try (PreparedStatement checkEmailStatement = connection.prepareStatement(checkEmailQuery)) {
                checkEmailStatement.setString(1, this.email);
                ResultSet emailResultSet = checkEmailStatement.executeQuery();
                if (emailResultSet.next() && emailResultSet.getInt(1) > 0) {
                    showAlert(Alert.AlertType.ERROR, "Duplicate Email", "An account with this email already exists. Please use a different email.");
                    return -1; 
                }
            }

            try (PreparedStatement checkNameStatement = connection.prepareStatement(checkNameQuery)) {
                checkNameStatement.setString(1, this.name);
                ResultSet nameResultSet = checkNameStatement.executeQuery();
                if (nameResultSet.next() && nameResultSet.getInt(1) > 0) {
                    showAlert(Alert.AlertType.ERROR, "Duplicate Name", "An account with this name already exists. Please use a different name.");
                    return -1; 
                }
            }

            try (PreparedStatement insertStatement = connection.prepareStatement(insertQuery, PreparedStatement.RETURN_GENERATED_KEYS)) {
                insertStatement.setString(1, this.name);
                insertStatement.setString(2, this.email);
                insertStatement.setString(3, this.password);
                insertStatement.setString(4, this.phonenumber);
                int rowsAffected = insertStatement.executeUpdate();

                if (rowsAffected > 0) {
               
                    ResultSet generatedKeys = insertStatement.getGeneratedKeys();
                    if (generatedKeys.next()) {
                        generatedId = generatedKeys.getInt(1);
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Failed to create account: " + e.getMessage());
        }

        return generatedId;
    }

 
    
    public void createAndAddBus(String busNumber, int capacity, String status) {
       
        Bus newBus = new Bus(busNumber, capacity, status);
        newBus.addBus();
    }
    
    public boolean deleteBus(String busNumber) {
       
    	return Bus.finallyDeleteBus(busNumber);
    }
    
    public void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null); // No header text
        alert.setContentText(message);
        alert.showAndWait();
    }

}