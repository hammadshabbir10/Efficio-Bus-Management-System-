package JAVAFX;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import DBLayer.DataBaseConnection;
import UI_Controller.PassengerScheduleController;

public class Passengers extends User {
 

    public Passengers() {   super(); }
    public Passengers(String name, String email, String password,String phonenumber) {
    	super(name, email,  password,phonenumber);
    } 

    @Override
    public int createAccount() {
        String checkEmailQuery = "SELECT COUNT(*) FROM Passengers WHERE email = ?";
        String checkNameQuery = "SELECT COUNT(*) FROM Passengers WHERE name = ?";
        String insertQuery = "INSERT INTO Passengers (name, email, password,phonenumber) VALUES (?, ?, ?,?)";
        int generatedId = -1;

        try (Connection connection = DataBaseConnection.getConnection()) {
            
            try (PreparedStatement checkEmailStatement = connection.prepareStatement(checkEmailQuery)) {
                checkEmailStatement.setString(1, this.email);
                ResultSet emailResultSet = checkEmailStatement.executeQuery();
                if (emailResultSet.next() && emailResultSet.getInt(1) > 0) {
                    showAlert(Alert.AlertType.ERROR, "Duplicate Email", "An account with this email already exists. Please use a different email.");
                    return -1; 
                }
            }

            try (PreparedStatement checkNameStatement = connection.prepareStatement(checkNameQuery)) {
                checkNameStatement.setString(1, this.name);
                ResultSet nameResultSet = checkNameStatement.executeQuery();
                if (nameResultSet.next() && nameResultSet.getInt(1) > 0) {
                    showAlert(Alert.AlertType.ERROR, "Duplicate Name", "An account with this name already exists. Please use a different name.");
                    return -1;
                }
            }

            try (PreparedStatement insertStatement = connection.prepareStatement(insertQuery, PreparedStatement.RETURN_GENERATED_KEYS)) {
                insertStatement.setString(1, this.name);
                insertStatement.setString(2, this.email);
                insertStatement.setString(3, this.password);
                insertStatement.setString(4, this.phonenumber);
                int rowsAffected = insertStatement.executeUpdate();

                if (rowsAffected > 0) {
                 
                    ResultSet generatedKeys = insertStatement.getGeneratedKeys();
                    if (generatedKeys.next()) {
                        generatedId = generatedKeys.getInt(1);
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Failed to create account: " + e.getMessage());
        }

        return generatedId;
    }

    public void fetchSchedule(String busNumber, PassengerScheduleController controller) {
        try (Connection connection = DataBaseConnection.getConnection()) {
            
            String query = "SELECT distance, startTime, endTime FROM Routes WHERE busNumber = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, busNumber);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
               
                double distance = resultSet.getDouble("distance");
                String startTime = resultSet.getString("startTime");
                String endTime = resultSet.getString("endTime");

                controller.updateScheduleFields(distance, startTime, endTime);
            } else {
             
                controller.showAlert(Alert.AlertType.INFORMATION, "No Schedule Found", "No schedule found for the selected bus.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
           
            controller.showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred while fetching schedule details.");
        }
    }
    
    public boolean hasBookedTicket() 
    {   
        int passengerId = LoggedInPassenger.getPassengerId();
        return Ticket.hasBookedTicket(passengerId);
    }

    public void submitFeedback(int rating, String feedback) 
    {  
        int passengerId = LoggedInPassenger.getPassengerId();
        Feedback feedbackObj = new Feedback();
        feedbackObj.submitFeedbackToDatabase(passengerId, rating, feedback);
    }
    
    public void lodgeComplaint(String complaintType, String complaintDescription, String stationManager) 
    {
        int passengerId = LoggedInPassenger.getPassengerId();
        Complaint complaint = new Complaint();
        complaint.saveComplaintToDatabase(passengerId, complaintType, complaintDescription, stationManager);
    }
    
    public void showAlert(AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null); // No header text
        alert.setContentText(message);
        alert.showAndWait(); // Show the alert and wait for the user to close it
    }
}