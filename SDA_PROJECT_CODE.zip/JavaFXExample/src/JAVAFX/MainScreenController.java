package JAVAFX;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import javafx.animation.FadeTransition;
import javafx.animation.TranslateTransition;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

public class MainScreenController {
    @FXML
    private Button adminButton;
    @FXML
    private Button stationManagerButton;
    @FXML
    private Button passengersButton;
    @FXML
    private Button exitButton;
    private Stage stage;
    @FXML
    private Label appLabel;
    @FXML
    private AnchorPane mainAnchorPane;
    @FXML
    private ImageView busImageView;


    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private void handleButtonHover(javafx.scene.input.MouseEvent event) {
        Button button = (Button) event.getSource();
        button.setStyle("-fx-background-color: #27ae60; -fx-background-radius: 10px; -fx-text-fill: white; -fx-font-size: 16px;");
    }

    @FXML
    private void handleButtonExit(javafx.scene.input.MouseEvent event) {
        Button button = (Button) event.getSource();
        button.setStyle("-fx-background-color: #2ecc71; -fx-background-radius: 10px; -fx-text-fill: white; -fx-font-size: 14px;");
    }
    
    
    @FXML
    private void handleButtonHoverExit(javafx.scene.input.MouseEvent event) {
        Button button = (Button) event.getSource();
        button.setStyle("-fx-background-color: #E53935; -fx-background-radius: 10px; -fx-text-fill: white; -fx-font-size: 16px;");
    }

    @FXML
    private void handleButtonExitExit(javafx.scene.input.MouseEvent event) {
        Button button = (Button) event.getSource();
        button.setStyle("-fx-background-color: #F44336; -fx-background-radius: 10px; -fx-text-fill: white; -fx-font-size: 14px;");
    }
    
    @FXML
    public void initialize() {
     
        slideInLabel(appLabel);   
        fadeInButton(adminButton);
        fadeInButton(stationManagerButton);
        fadeInButton(passengersButton);
        fadeInButton(exitButton);
        
        
    }

    private void slideInLabel(Node node) {
        TranslateTransition slideIn = new TranslateTransition(Duration.seconds(1), node);
        slideIn.setFromY(-50); 
        slideIn.setToY(30); 
        slideIn.setCycleCount(1);
        slideIn.setAutoReverse(false);
        slideIn.play();
    }

    private void fadeInButton(Node node) {
        FadeTransition fadeIn = new FadeTransition(Duration.seconds(1), node);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0); 
        fadeIn.setCycleCount(1);
        fadeIn.setAutoReverse(false);
        fadeIn.play();
    }
    @FXML
    private void handleExitButtonClick() {
        
        javafx.application.Platform.exit();
        System.exit(0); 
    }
    
    @FXML
    private void handleStationManagerButtonClick() 
    {
    	slideInStationManagerLoginScreen();
    }

    private void slideInStationManagerLoginScreen() {
        try {
          
            Parent LoginScreen = FXMLLoader.load(getClass().getResource("/FXML_FILES/StationManagerLoginScreen.fxml"));
            LoginScreen.translateXProperty().set(mainAnchorPane.getWidth());
            mainAnchorPane.getChildren().add(LoginScreen);

            TranslateTransition slideIn = new TranslateTransition(Duration.seconds(0.4),LoginScreen);
            slideIn.setFromX(mainAnchorPane.getWidth());
            slideIn.setToX(0); 
            slideIn.setCycleCount(1);
            slideIn.setAutoReverse(false);
            slideIn.play();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void navigateToStationManagerLoginScreen() {
        try {
            
            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/StationManagerLoginScreen.fxml"));
            Stage stage = (Stage) stationManagerButton.getScene().getWindow();
            Scene scene = new Scene(root, 500, 600); 
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    private void handleAdminButtonClick() 
    {
    	slideInAdminLoginScreen();
    }
    
    private void slideInAdminLoginScreen() {
        try {
          
            Parent adminLoginScreen = FXMLLoader.load(getClass().getResource("/FXML_FILES/AdminLoginScreen.fxml"));
            adminLoginScreen.translateXProperty().set(mainAnchorPane.getWidth());
            mainAnchorPane.getChildren().add(adminLoginScreen);

            TranslateTransition slideIn = new TranslateTransition(Duration.seconds(0.4), adminLoginScreen);
            slideIn.setFromX(mainAnchorPane.getWidth());
            slideIn.setToX(0); 
            slideIn.setCycleCount(1);
            slideIn.setAutoReverse(false);
            slideIn.play();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void navigateToAdminLoginScreen() {
        try {
            
            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/AdminLoginScreen.fxml"));
            Stage stage = (Stage) adminButton.getScene().getWindow();
            Scene scene = new Scene(root, 500, 600); 
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    private void handlePassengerButtonClick() 
    {
    	slideInPassengerLoginScreen();
    }
    
    private void slideInPassengerLoginScreen() {
        try {
          
            Parent LoginScreen = FXMLLoader.load(getClass().getResource("/FXML_FILES/PassengerLoginScreen.fxml"));
            LoginScreen.translateXProperty().set(mainAnchorPane.getWidth());
            mainAnchorPane.getChildren().add(LoginScreen);

            TranslateTransition slideIn = new TranslateTransition(Duration.seconds(0.4), LoginScreen);
            slideIn.setFromX(mainAnchorPane.getWidth());
            slideIn.setToX(0); 
            slideIn.setCycleCount(1);
            slideIn.setAutoReverse(false);
            slideIn.play();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void navigateToPassengerLoginScreen() {
        try {
            
            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/PassengerLoginScreen.fxml"));
            Stage stage = (Stage) passengersButton.getScene().getWindow();
            Scene scene = new Scene(root, 500, 600); 
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
