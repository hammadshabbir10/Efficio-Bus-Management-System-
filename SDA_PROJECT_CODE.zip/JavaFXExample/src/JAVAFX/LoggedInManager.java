package JAVAFX;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import DBLayer.DataBaseConnection;

public class LoggedInManager 
{
    private static String name; 
    public static void setName(String managerName) 
    {
        name = managerName;
    }
    public static String getName() 
    {
        return name;
    }

    public void login(String name, String password) {
        try {
          
            Connection connection = DataBaseConnection.getConnection();
            Statement statement = connection.createStatement();
            
            String query = "SELECT name FROM StationManager WHERE name = '" + name + "' AND password = '" + password + "'";
            ResultSet resultSet = statement.executeQuery(query);
            
            if (resultSet.next()) {
                String managerName = resultSet.getString("name"); 
                LoggedInManager.setName(managerName); 
                System.out.println("Login successful. Manager Name: " + managerName);
            } else {
               
                System.out.println("Invalid username or password.");
            }
           
            resultSet.close();
            statement.close();
            connection.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}