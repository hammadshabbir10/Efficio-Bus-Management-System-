package JAVAFX;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import DBLayer.DataBaseConnection;

public class Ticket {
    private int ticketId;
    private int passengerId;
    private int routeId;
    private int busId;
    private LocalDate bookingDate;
    private String seatNumber;
    private double fare;

    public Ticket(int ticketId, int passengerId, int routeId, int busId, LocalDate bookingDate, String seatNumber, double fare) {
        this.ticketId = ticketId;
        this.passengerId = passengerId;
        this.routeId = routeId;
        this.busId = busId;
        this.bookingDate = bookingDate;
        this.seatNumber = seatNumber;
        this.fare = fare;
    }

    public int getTicketId() {
        return ticketId;
    }

    public void setTicketId(int ticketId) {
        this.ticketId = ticketId;
    }

    public int getPassengerId() {
        return passengerId;
    }

    public void setPassengerId(int passengerId) {
        this.passengerId = passengerId;
    }

    public int getRouteId() {
        return routeId;
    }

    public void setRouteId(int routeId) {
        this.routeId = routeId;
    }

    public int getBusId() {
        return busId;
    }

    public void setBusId(int busId) {
        this.busId = busId;
    }

    public LocalDate getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(LocalDate bookingDate) {
        this.bookingDate = bookingDate;
    }

    public String getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }

    public double getFare() {
        return fare;
    }

    public void setFare(double fare) {
        this.fare = fare;
    }

    public static boolean isTicketIdValid(String ticketId) {
        String query = "SELECT COUNT(*) FROM tickets WHERE ticketId = ?";
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            
            stmt.setString(1, ticketId);
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt(1) > 0; 
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; 
    }
    
    public static boolean hasBookedTicket(int passengerId) {
   
        try (Connection connection = DataBaseConnection.getConnection()) {
            String query = "SELECT COUNT(*) FROM Tickets WHERE passengerId = ?";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, passengerId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }    
    
    public static boolean isTicketOwnedByPassenger(String ticketId, int passengerId) {
        String query = "SELECT COUNT(*) FROM Tickets WHERE ticketId = ? AND passengerId = ?";
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            
            stmt.setString(1, ticketId);
            stmt.setInt(2, passengerId);

            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public String displayTicketDetails() {
        return "Ticket ID: " + ticketId +
                "\nPassenger ID: " + passengerId +
                "\nRoute ID: " + routeId +
                "\nBus ID: " + busId +
                "\nBooking Date: " + bookingDate +
                "\nSeat Number: " + seatNumber +
                "\nFare: $" + fare;
    }
}
