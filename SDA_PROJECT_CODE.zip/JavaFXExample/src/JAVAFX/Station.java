package JAVAFX;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import DBLayer.DataBaseConnection;

public class Station {
    private String name;
    private String location;

    public Station(String name, String location) 
    {
        this.name = name;
        this.location = location;
    }

    public boolean insertStationIntoDB() {
        try (Connection connection = DataBaseConnection.getConnection()) {
            String insertStationQuery = "INSERT INTO Station (name, location) VALUES (?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertStationQuery);
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, location);
            preparedStatement.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public static boolean finallyDeleteStation(String name) {
        try (Connection conn = DataBaseConnection.getConnection()) {
            conn.setAutoCommit(false); 
            int stationId = -1;

            String getStationIdQuery = "SELECT stationId FROM Station WHERE name = ?";
            try (PreparedStatement getStationIdStmt = conn.prepareStatement(getStationIdQuery)) {
                getStationIdStmt.setString(1, name);
                ResultSet rs = getStationIdStmt.executeQuery();
                if (rs.next()) {
                    stationId = rs.getInt("stationId");
                }
                rs.close();
            }

            if (stationId == -1) {
                System.out.println("Station not found: " + name);
                return false;
            }

            String activeRouteCheckQuery = 
                "SELECT sba.busNumber FROM StationBusAssignments sba " +
                "JOIN Routes r ON sba.busNumber = r.busNumber " +
                "WHERE sba.stationName = ?";
            try (PreparedStatement activeRouteCheckStmt = conn.prepareStatement(activeRouteCheckQuery)) {
                activeRouteCheckStmt.setString(1, name);
                ResultSet rs = activeRouteCheckStmt.executeQuery();
                if (rs.next()) {
                    showAlert("Error","Cannot delete station: Active routes exist for buses at this station.");
                    return false; 
                }
                rs.close();
            }


            String deleteFromManagerStationsQuery = "DELETE FROM StationManagerStations WHERE stationName = ?";
            try (PreparedStatement deleteFromManagerStationsStmt = conn.prepareStatement(deleteFromManagerStationsQuery)) {
                deleteFromManagerStationsStmt.setString(1, name);
                deleteFromManagerStationsStmt.executeUpdate();
            }

            String deleteFromBusAssignmentsQuery = "DELETE FROM StationBusAssignments WHERE stationName = ?";
            try (PreparedStatement deleteFromBusAssignmentsStmt = conn.prepareStatement(deleteFromBusAssignmentsQuery)) {
                deleteFromBusAssignmentsStmt.setString(1, name);
                deleteFromBusAssignmentsStmt.executeUpdate();
            }
            
            String deleteFromRoutesQuery = "DELETE FROM Routes WHERE startStation = ? OR endStation = ?";
            try (PreparedStatement deleteFromRoutesStmt = conn.prepareStatement(deleteFromRoutesQuery)) {
                deleteFromRoutesStmt.setString(1, name);
                deleteFromRoutesStmt.setString(2, name);
                deleteFromRoutesStmt.executeUpdate();
            }

            String deleteStationQuery = "DELETE FROM Station WHERE name = ?";
            try (PreparedStatement deleteStationStmt = conn.prepareStatement(deleteStationQuery)) {
                deleteStationStmt.setString(1, name);
                deleteStationStmt.executeUpdate();
            }

            conn.commit();
            showAlert("Success","Station and associated data deleted successfully.");
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    private static void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    
 
}