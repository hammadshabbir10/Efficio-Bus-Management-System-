
package JAVAFX;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class StationManagerScreen {
    private Stage stage;

    public StationManagerScreen(Stage stage) {
        this.stage = stage;
    }

    public Scene createStationManagerScene() {
        try 
        {
            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/StationManagerScreen.fxml"));
            return new Scene(root, 600, 400);
        } 
        catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
