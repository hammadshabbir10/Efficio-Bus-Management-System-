package JAVAFX;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;


public class JavaFX extends Application {

    @Override
    public void start(Stage primaryStage) throws IOException {
       
        UI_Controller.MainScreen mainScreen = new UI_Controller.MainScreen(primaryStage);
        Scene mainScene = mainScreen.createMainScene();

        if (mainScene != null) {
    
            primaryStage.setTitle("EFFICIO BUS MANAGEMENT SYSTEM");
            primaryStage.setWidth(800); 
            primaryStage.setHeight(600); 
            primaryStage.setScene(mainScene);
            primaryStage.setResizable(false);

            primaryStage.show();
        } else {
            System.out.println("Failed to load the FXML scene.");
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
