package JAVAFX;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Bus {

    private String busNumber;
    private int capacity;
    private String status;

    public Bus(String busNumber, int capacity, String status) {
        
        this.busNumber = busNumber;
        this.capacity = capacity;
        this.status = status;
    }

    public void addBus() {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
          
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/BMS", "root", "mostwanted3z");
            String sql = "INSERT INTO Bus (busNumber, capacity, status) VALUES ( ?, ?, ?)";
            preparedStatement = connection.prepareStatement(sql); 
            preparedStatement.setString(1, busNumber);
            preparedStatement.setInt(2, capacity);
            preparedStatement.setString(3, status);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Bus added successfully to the database!");
            } else {
                System.out.println("Failed to add the bus to the database.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } 
        finally 
        {
           
            try 
            {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static boolean finallyDeleteBus(String busNumber) {
        Connection connection = null;
        PreparedStatement checkStatusStmt = null;
        PreparedStatement deleteTicketsStmt = null;
        PreparedStatement deleteRoutesStmt = null;
        PreparedStatement deleteAssignmentsStmt = null;
        PreparedStatement deleteBusStmt = null;
        PreparedStatement getBusIdStmt = null;

        try {
        
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/BMS", "root", "mostwanted3z");

            String checkStatusSQL = "SELECT status FROM Bus WHERE busNumber = ?";
            checkStatusStmt = connection.prepareStatement(checkStatusSQL);
            checkStatusStmt.setString(1, busNumber);
            ResultSet rs = checkStatusStmt.executeQuery();

            if (rs.next()) {
                String status = rs.getString("status");
                if ("Rented".equalsIgnoreCase(status)) {
                    System.out.println("Bus is currently rented and cannot be deleted.");
                    return false;
                }
            } else {
                System.out.println("Bus with busNumber " + busNumber + " not found!");
                return false;
            }

            connection.setAutoCommit(false);

            String getBusIdSQL = "SELECT busId FROM Bus WHERE busNumber = ?";
            getBusIdStmt = connection.prepareStatement(getBusIdSQL);
            getBusIdStmt.setString(1, busNumber);
            ResultSet busIdResult = getBusIdStmt.executeQuery();

            int busId = -1; 
            if (busIdResult.next()) {
                busId = busIdResult.getInt("busId");
            }

            if (busId == -1) {
                System.out.println("Bus with busNumber " + busNumber + " not found!");
                return false;
            }

            String deleteTicketsSQL = "DELETE FROM Tickets WHERE busId = ?";
            deleteTicketsStmt = connection.prepareStatement(deleteTicketsSQL);
            deleteTicketsStmt.setInt(1, busId);  // Use busId for deletion
            deleteTicketsStmt.executeUpdate();

            // Delete routes first, before deleting the bus
            /*String deleteRoutesSQL = "DELETE FROM Routes WHERE busNumber = ?";
            deleteRoutesStmt = connection.prepareStatement(deleteRoutesSQL);
            deleteRoutesStmt.setString(1, busNumber);
            deleteRoutesStmt.executeUpdate();*/

            String deleteAssignmentsSQL = "DELETE FROM StationBusAssignments WHERE busNumber = ?";
            deleteAssignmentsStmt = connection.prepareStatement(deleteAssignmentsSQL);
            deleteAssignmentsStmt.setString(1, busNumber);
            deleteAssignmentsStmt.executeUpdate();

            String deleteBusSQL = "DELETE FROM Bus WHERE busNumber = ?";
            deleteBusStmt = connection.prepareStatement(deleteBusSQL);
            deleteBusStmt.setString(1, busNumber);
            int rowsDeleted = deleteBusStmt.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println("Bus deleted successfully!");
            } else {
                System.out.println("Bus deletion failed!");
                connection.rollback();
                return false;
            }

            connection.commit();
            return true;

        } catch (SQLException e) {
           
            if (connection != null) {
                try {
                    connection.rollback();
                    System.out.println("Transaction rolled back due to an error.");
                } catch (SQLException rollbackEx) {
                    rollbackEx.printStackTrace();
                }
            }
            e.printStackTrace();
            return false;

        } finally {
           
            try {
                if (checkStatusStmt != null) checkStatusStmt.close();
                if (deleteTicketsStmt != null) deleteTicketsStmt.close();
                if (deleteRoutesStmt != null) deleteRoutesStmt.close();
                if (deleteAssignmentsStmt != null) deleteAssignmentsStmt.close();
                if (deleteBusStmt != null) deleteBusStmt.close();
                if (getBusIdStmt != null) getBusIdStmt.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}